package insa.soa.UserList.model;

public class UserVolunteer {
	
	// Volunteers info
	public String name;
	public String localization;
	public int ID;
	
	// Constructors
	public UserVolunteer (String name, String localization, int ID) {
		this.name = name;
		this.localization = localization;
		this.ID = ID;
	}
	public UserVolunteer() {
	}
	
	// Getters
	public String getName() {
		return name;
	}
	public String getLocalization() {
		return localization;
	}
	public int getID() {
		return ID;
	}
	
	// Setters
	public void setName(String name) {
		this.name = name;
	}
	public void setLocalisation(String localization) {
		this.localization = localization;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
}
