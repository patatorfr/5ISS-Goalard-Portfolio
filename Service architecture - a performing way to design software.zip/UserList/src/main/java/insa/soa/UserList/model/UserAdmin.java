package insa.soa.UserList.model;

public class UserAdmin {
	
	// Admin info
	public String name;
	public int ID;
	public String password;
	
	// Constructors
	public UserAdmin (String name, int ID) {
		this.name = name;
		this.ID = ID;
	}
	public UserAdmin() {
	}
	
	// Getters
	public String getName() {
		return name;
	}
	public int getID() {
		return ID;
	}
	public String getPassword() {
		return password;
	}
	
	// Setters
	public void setName(String name) {
		this.name = name;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public void setPassword(String pswd) {
		this.password = pswd;
	}
}
