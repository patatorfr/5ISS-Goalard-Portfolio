package insa.soa.UserList.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import java.sql.PreparedStatement;

//This microservice is accessible through Eureka discovery using : http://userCreationService/...

@RestController
@RequestMapping("/users")
public class UserResource {
	
	@Autowired
	private RestTemplate restTemplate;

	//Call example : http://localhost:8091/users/createAdmin?name=anto&password=wesh
	@GetMapping("createAdmin")
	public void createAdmin(@RequestParam("name") String name, @RequestParam("password") String password, HttpServletResponse response) {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String pssd = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, pssd);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the INSERT query with parameters
			String SQL = "INSERT INTO Admin (name, password, role_id) VALUES (?, ?, 3)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
	            preparedStatement.setString(1, name);
	            preparedStatement.setString(2, password);
	            int numRowsInserted = preparedStatement.executeUpdate();
	            //Shows the added admin
	            System.out.println("Number of admin added : "+ numRowsInserted);
			}
			//Close the resources
			statement.close();
			connection.close();
			//Display message on web page
            String message = "You have been added as an admin !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            	}
        	}
    	}
	
	//Call example : http://localhost:8091/users/createVolunteer?name=Pierre&localization=Toulouse
	@GetMapping("createVolunteer")
	public void createVolunteer(@RequestParam("name") String name, @RequestParam("localization") String localization, HttpServletResponse response) {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the INSERT query with parameters
			String SQL = "INSERT INTO Volunteer (name, localization, role_id) VALUES (?, ?, 2)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
	            preparedStatement.setString(1, name);
	            preparedStatement.setString(2, localization);
	            int numRowsInserted = preparedStatement.executeUpdate();
	            //Shows the added Volunteer
	            System.out.println("Number of Volunteer added : "+ numRowsInserted);
			}
			//Close the resources
			statement.close();
			connection.close();
			//Display message on web page
            String message = "You have been added as a volunteer !";
            response.getWriter().write(message);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            	}
        	}
    	}
	
	//Call example : http://localhost:8091/users/createNeeder?name=Antonin&localization=Toulouse
	@GetMapping("createNeeder")
	public void createNeeder(@RequestParam("name") String name, @RequestParam("localization") String localization, HttpServletResponse response) {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the INSERT query with parameters
			String SQL = "INSERT INTO Needer (name, localization, role_id) VALUES (?, ?, 1)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
	            preparedStatement.setString(1, name);
	            preparedStatement.setString(2, localization);
	            int numRowsInserted = preparedStatement.executeUpdate();
	            //Shows the added Needer
	            System.out.println("Number of Needer added : "+ numRowsInserted);
			}
			//Close the resources
			statement.close();
			connection.close();
			//Display message on web page
            String message = "You have been added as a needer !";
            response.getWriter().write(message);
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            	}
        	}
    	}
	
	//Call : http://localhost:8091/users/retrieveAdmin
	@GetMapping("retrieveAdmin")
	public void retrieveAdmin() {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the select query
			String SQL = "SELECT * FROM Admin";
			ResultSet resultSet = statement.executeQuery(SQL);
			//Process the ResultSet (rpz result of the query)
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String adminName = resultSet.getString("name");
				System.out.println("ID : "+ id +", Name : "+ adminName + ", Rôle : Admin");
			}
			//Close the resources
			resultSet.close();
			statement.close();
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
	
	//Call : http://localhost:8091/users/retrieveVolunteer
	@GetMapping("retrieveVolunteer")
	public void retrieveVolunteer() {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the select query
			String SQL = "SELECT * FROM Volunteer";
			ResultSet resultSet = statement.executeQuery(SQL);
			//Process the ResultSet (rpz result of the query)
			while (resultSet.next()) {
				String volunteerName = resultSet.getString("name");
				String localization = resultSet.getString("localization");
				System.out.println("Name : "+ volunteerName + ", Localisation : "+localization+ ", Rôle : Volunteer");
			}
			//Close the resources
			resultSet.close();
			statement.close();
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
	
	//Call : http://localhost:8091/users/retrieveNeeder
	@GetMapping("retrieveNeeder")
	public void retrieveNeeder() {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the select query
			String SQL = "SELECT * FROM Needer";
			ResultSet resultSet = statement.executeQuery(SQL);
			//Process the ResultSet (rpz result of the query)
			while (resultSet.next()) {
				String volunteerName = resultSet.getString("name");
				String localization = resultSet.getString("localization");
				System.out.println("Name : "+ volunteerName + ", Localisation : "+localization+ ", Rôle : Needer");
			}
			//Close the resources
			resultSet.close();
			statement.close();
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
		
}
