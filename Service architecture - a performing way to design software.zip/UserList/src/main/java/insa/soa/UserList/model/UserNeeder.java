package insa.soa.UserList.model;

public class UserNeeder {

	// Needer info
	public String name;
	public String localisation;
	public int ID;
	
	// Constructors
	public UserNeeder (String name, String localisation, int ID) {
		this.name = name;
		this.localisation = localisation;
		this.ID = ID;
	}
	public UserNeeder() {
	}
	
	// Getters
	public String getName() {
		return name;
	}
	public String getLocalisation() {
		return localisation;
	}
	public int getID() {
		return ID;
	}
	
	// Setters
	public void setName(String name) {
		this.name = name;
	}
	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
}
