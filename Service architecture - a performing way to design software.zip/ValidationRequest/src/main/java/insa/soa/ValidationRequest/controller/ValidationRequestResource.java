package insa.soa.ValidationRequest.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//This microservice is accessible through Eureka discovery using : http://validationRequestService/...

@RestController
@RequestMapping("/request")
public class ValidationRequestResource {
	
	@Autowired
	private RestTemplate restTemplate;

    @GetMapping("test")
    public int studentn() {
        return 10;
    }

    // Call example : http://localhost:8093/request/validateRequest?adminName=anto&adminPassword=wesh&missionId=1
    @GetMapping("validateRequest")
    public void validateRequest(
        @RequestParam("adminName") String adminName,
        @RequestParam("adminPassword") String adminPassword,
        @RequestParam("missionId") String missionId,
    	HttpServletResponse response){
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);
            // Create the Statement object
            Statement statement = connection.createStatement();
            // Query to check if the admin credentials are valid
            String adminValidationQuery = "SELECT COUNT(*) AS count FROM Admin WHERE name = ? AND password = ?";
            try (PreparedStatement adminValidationStatement = connection.prepareStatement(adminValidationQuery)) {
                adminValidationStatement.setString(1, adminName);
                adminValidationStatement.setString(2, adminPassword);
                ResultSet adminValidationResult = adminValidationStatement.executeQuery();
                // Check if there is at least one result in the set (means that there is a duet name<=>password
                if (adminValidationResult.next() && adminValidationResult.getInt("count") > 0) {
                    String updateRequestStatus = "UPDATE Missions SET status = 'accepted' WHERE id = ?";
                    try (PreparedStatement updateStatusStatement = connection.prepareStatement(updateRequestStatus)) {
                        updateStatusStatement.setString(1, missionId);
                        int rowsAffected = updateStatusStatement.executeUpdate();
                        System.out.println("Mission " + missionId + " is now accepted");
                    }
                } else {
                    System.out.println("You are not allowed to do that");
                }
            }
            // Close the resources
            statement.close();
            connection.close();
            //Display message on web page
            String message = "You just validated a request !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
            } catch (ClassNotFoundException | SQLException | IOException e) {
                e.printStackTrace();
                String errorMessage = "An error occured";
                try {
                	response.getWriter().write(errorMessage);
                	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                } catch (IOException ioException) {
                	ioException.printStackTrace();
                	}
            	}
            }
    
    // Call example : http://localhost:8093/request/refuseRequest?adminName=anto&adminPassword=wesh&missionId=2&declineMotive=non
    @GetMapping("refuseRequest")
    public void refuseRequest(
        @RequestParam("adminName") String adminName,
        @RequestParam("adminPassword") String adminPassword,
        @RequestParam("missionId") String missionId,
        @RequestParam("declineMotive") String declineMotive,
        HttpServletResponse response){
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);
            // Create the Statement object
            Statement statement = connection.createStatement();
            // Query to check if the admin credentials are valid
            String adminValidationQuery = "SELECT COUNT(*) AS count FROM Admin WHERE name = ? AND password = ?";
            try (PreparedStatement adminValidationStatement = connection.prepareStatement(adminValidationQuery)) {
                adminValidationStatement.setString(1, adminName);
                adminValidationStatement.setString(2, adminPassword);
                ResultSet adminValidationResult = adminValidationStatement.executeQuery();
                // Check if there is at least one result in the set (means that there is a duet name<=>password
                if (adminValidationResult.next() && adminValidationResult.getInt("count") > 0) {
                    String updateRequestStatus = "UPDATE Missions SET status = 'declined', declineReason = ? WHERE id = ?";
                    try (PreparedStatement updateStatusStatement = connection.prepareStatement(updateRequestStatus)) {
                    	updateStatusStatement.setString(1, declineMotive);
                        updateStatusStatement.setString(2, missionId);
                        int rowsAffected = updateStatusStatement.executeUpdate();
                        System.out.println("Mission " + missionId + " is declined");
                    }
                } else {
                    System.out.println("You are not allowed to do that");
                }
            }
            // Close the resources
            statement.close();
            connection.close();
            //Display message on web page
            String message = "You refused a request, the reason is vailable for the needer to see !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
            } catch (ClassNotFoundException | SQLException | IOException e) {
                e.printStackTrace();
                String errorMessage = "An error occured";
                try {
                	response.getWriter().write(errorMessage);
                	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                } catch (IOException ioException) {
                	ioException.printStackTrace();
                	}
            	}
            }
    
    
}
