package insa.soa.AddRequest.model;

public class Mission {
	
	//Mission info
	public String volunteer;
	public String description;
	public String neederName;
	public String localization;
	public String status;
	
	//Mission constructors
	public Mission (String volunteer, String description, String neederName, String localization, String status) {
		this.volunteer = volunteer;
		this.description = description;
		this.neederName = neederName;
		this.localization = localization;
		this.status = status;
	}
	public Mission() {
	}
	
	//Getters
	public String getVolunteer() {
		return volunteer;
	}
	public String getDescription() {
		return description;
	}
	public String getNeeder() {
		return neederName;
	}
	public String getLocalization() {
		return localization;
	}
	public String getStatus() {
		return status;
	}
	
	//Setters
	public void setVolunteer(String volunteer) {
		this.volunteer = volunteer;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setNeeder(String needer) {
		this.neederName = needer;
	}
	public void setLocalization(String localization) {
		this.localization = localization;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}