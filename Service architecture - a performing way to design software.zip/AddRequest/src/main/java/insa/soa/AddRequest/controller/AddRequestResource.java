package insa.soa.AddRequest.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

//This microservice is accessible through Eureka discovery using : http://addRequestService/...

@RestController
@RequestMapping("/request")
public class AddRequestResource {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("test")
	public int studentn() {
		return 10;
	}

	//Call example : http://localhost:8092/request/createRequest?neederName=antonin&description=anotherMission
	@GetMapping("createRequest")
	public void createRequest(@RequestParam("neederName") String neederName, @RequestParam("description") String description, HttpServletResponse response) {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Find the localization of the needer who create the request
			String localizationQuery = "SELECT localization FROM Needer WHERE name = '"+neederName + "'";
			ResultSet localizationResult = statement.executeQuery(localizationQuery);
			if (localizationResult.next()) {
				String localization = localizationResult.getString("localization");
				//Execute the queries with parameters
				String SQL = "INSERT INTO Missions (neederName, description, localization, status) VALUES (?, ?, ?, 'waiting')";
				try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
					preparedStatement.setString(1, neederName);
			        preparedStatement.setString(2, description);
			        preparedStatement.setString(3, localization);
			        int numRowsInserted = preparedStatement.executeUpdate();
			        //Shows the added mission
			        System.out.println("Mission added " + numRowsInserted);
			        }
				} else {
					String SQL = "INSERT INTO Missions (neederName, description, status) VALUES (?, ?, 'waiting')";
					try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
			            preparedStatement.setString(1, neederName);
			            preparedStatement.setString(2, description);
			            int numRowsInserted = preparedStatement.executeUpdate();
			            //Shows the added mission
			            System.out.println("Mission added " + numRowsInserted);
					}
				}
			//Close the resources
			statement.close();
			connection.close();
			//Display message on web page
            String message = "Your request has been sent, an admin will look at it soon !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
			} catch (ClassNotFoundException | SQLException | IOException e) {
	            e.printStackTrace();
	            String errorMessage = "An error occured";
	            try {
	            	response.getWriter().write(errorMessage);
	            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            } catch (IOException ioException) {
	            	ioException.printStackTrace();
	            	}
	        	}
	        }
		
	//Call example : http://localhost:8092/request/retrieveNeederMissions?needer=antonin
	@GetMapping("retrieveNeederMissions")
	public void retrieveNeederMissions(@RequestParam("needer") String needer) {
		try {			
			//Load the MySQL JDBS driver
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//Connect to the database
			String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
			String username = "projet_gei_046";
			String password = "wahn8Xei";
			Connection connection = DriverManager.getConnection(dbURL, username, password);
			//Create the Statement object
			Statement statement = connection.createStatement();
			//Execute the select query
			String SQL = "SELECT * FROM Missions WHERE neederName = ?";
			try (PreparedStatement preparedStatement = connection.prepareStatement(SQL)) {
			    preparedStatement.setString(1, needer);
			    ResultSet resultSet = preparedStatement.executeQuery();
			    //Process the ResultSet (rpz result of the query)
				while (resultSet.next()) {
					int id = resultSet.getInt("id");
					String neederName = resultSet.getString("neederName");
					String description = resultSet.getString("description");
					String localization = resultSet.getString("localization");
					String status = resultSet.getString("status");
					String volunteer = resultSet.getString("volunteer");
					System.out.println("ID : "+ id +", neederName : "+ neederName + ", description : "+ description +", localization : " + localization +", volunteer : "+ volunteer+", status : "+ status);
				}
				resultSet.close();
			}
			//Close the resources
			statement.close();
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
}

