package insa.soa.SelectMission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelectMissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
