package insa.soa.SelectMission.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

//This microservice is accessible through Eureka discovery using : http://selectMissionService/...

@RestController
@RequestMapping("/mission")
public class SelectMissionResource {
	
	@Autowired
	private RestTemplate restTemplate;
	
    @GetMapping("test")
    public int studentn() {
        return 10;
    }
    
    // Call example: http://localhost:8094/mission/choseRandomMission?volunteerName=Pierre
    @GetMapping("choseRandomMission")
    public void choseRandomMission(@RequestParam("volunteerName") String volunteerName, HttpServletResponse response) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);        
            // Retrieve volunteer localization
            String localizationQuery = "SELECT localization FROM Volunteer WHERE name = ?";
            try (PreparedStatement localizationStatement = connection.prepareStatement(localizationQuery)) {
                localizationStatement.setString(1, volunteerName);
                ResultSet localizationResult = localizationStatement.executeQuery();
                if (localizationResult.next()) {
                    String volunteerLoc = localizationResult.getString("localization");
                    // Query to take the first 'accepted' mission from the volunteer's localization
                    String missionQuery = "SELECT * FROM Missions WHERE localization = ? AND status = 'accepted' LIMIT 1";
                    try (PreparedStatement missionStatement = connection.prepareStatement(missionQuery)) {
                        missionStatement.setString(1, volunteerLoc);
                        ResultSet missionResult = missionStatement.executeQuery();
                        if (missionResult.next()) {
                            // Step 3: Update the mission's 'volunteer' and 'status'
                            int missionId = missionResult.getInt("id");
                            String updateMissionQuery = "UPDATE Missions SET volunteer = ?, status = 'chosen' WHERE id = ?";
                            try (PreparedStatement updateMissionStatement = connection.prepareStatement(updateMissionQuery)) {
                                updateMissionStatement.setString(1, volunteerName);
                                updateMissionStatement.setInt(2, missionId);
                                int rowsAffected = updateMissionStatement.executeUpdate();
                                if (rowsAffected > 0) {
                                    System.out.println("Mission assigned to " + volunteerName);
                                } else {
                                    System.out.println("Failed to assign mission.");
                                }
                            }
                        } else {
                            System.out.println("No missions available for this localization.");
                        }
                    }
                } else {
                    System.out.println("No localization found for the volunteer.");
                }
            }
            // Close the resources
            connection.close();
            //Display message on web page
            String message = "You have been attributed a random mission in your area, further details are available in the database !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (ClassNotFoundException | SQLException | IOException e) {
            e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            }
        }
    }

    // Choose a mission knowing it's ID (need access to DB or a function that retrieves all the missions)
    // Call example: http://localhost:8094/mission/chooseMission?volunteerName=Pierre&missionId=4
    @GetMapping("chooseMission")
    public void chooseMission(
            @RequestParam("volunteerName") String volunteerName,
            @RequestParam("missionId") int missionId,
            HttpServletResponse response) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);
            String missionQuery = "SELECT * FROM Missions WHERE id = ? AND status = 'accepted'";
            try (PreparedStatement missionStatement = connection.prepareStatement(missionQuery)) {
                missionStatement.setInt(1, missionId);
                ResultSet missionResult = missionStatement.executeQuery();
                if (missionResult.next()) {
                    // Mission is available, proceed with assignment
                    String updateMissionQuery = "UPDATE Missions SET volunteer = ?, status = 'chosen' WHERE id = ?";
                    try (PreparedStatement updateMissionStatement = connection.prepareStatement(updateMissionQuery)) {
                        updateMissionStatement.setString(1, volunteerName);
                        updateMissionStatement.setInt(2, missionId);
                        int rowsAffected = updateMissionStatement.executeUpdate();
                        if (rowsAffected > 0) {
                            System.out.println("Mission " + missionId + " assigned to " + volunteerName);
                        } else {
                            System.out.println("Failed to assign mission.");
                        }
                    }
                } else {
                    System.out.println("Mission " + missionId + " not available or already chosen.");
                }
            }
            // Close the resources
            connection.close();
            //Display message on web page
            String message = "You have been related to the mission you wanted, good luck !";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (ClassNotFoundException | SQLException | IOException e) {
            e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            }
        }
    }
}
