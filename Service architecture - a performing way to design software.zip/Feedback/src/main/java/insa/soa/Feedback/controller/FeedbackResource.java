package insa.soa.Feedback.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

//This microservice is accessible through Eureka discovery using : http://feedbackService/...

@RestController
@RequestMapping("/feedback")
public class FeedbackResource {
	
	@Autowired
	private RestTemplate restTemplate;

	//Use to be sure microservice is running
    @GetMapping("test")
    public int studentn() {
        return 10;
    }
    
    //Call example : http://localhost:8095/feedback/neederFeedback?missionId=4&feedback=oktier
    @GetMapping("neederFeedback")
    public void neederFeedback(@RequestParam("missionId") int missionId, @RequestParam("feedback") String feedback, HttpServletResponse response) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);
            // Retrieve values related to the mission to put it in the feedback table
            String valuesQuery = "SELECT neederName, description, volunteer FROM Missions WHERE id = ?";
            try (PreparedStatement valuesStatement = connection.prepareStatement(valuesQuery)) {
                valuesStatement.setInt(1, missionId);
                try (ResultSet valuesResult = valuesStatement.executeQuery()) {
                    if (valuesResult.next()) {
                        String neederName = valuesResult.getString("neederName");
                        String description = valuesResult.getString("description");
                        String volunteer = valuesResult.getString("volunteer");                    
                        // Check if the mission already exists in the Feedback table
                        String checkMissionQuery = "SELECT * FROM Feedback WHERE neederName = ? AND description = ?";
                        try (PreparedStatement checkMissionStatement = connection.prepareStatement(checkMissionQuery)) {
                            checkMissionStatement.setString(1, neederName);
                            checkMissionStatement.setString(2, description);
                            try (ResultSet checkMissionResult = checkMissionStatement.executeQuery()) {
                                if (checkMissionResult.next()) {
                                    // Mission already exists, update the feedback
                                    String updateFeedbackQuery = "UPDATE Feedback SET neederFeedback = ? WHERE neederName = ? AND description = ?";
                                    try (PreparedStatement updateFeedbackStatement = connection.prepareStatement(updateFeedbackQuery)) {
                                        updateFeedbackStatement.setString(1, feedback);
                                        updateFeedbackStatement.setString(2, neederName);
                                        updateFeedbackStatement.setString(3, description);
                                        updateFeedbackStatement.executeUpdate();
                                    }
                                } else {
                                    // Mission doesn't exist, insert a new feedback record
                                    String feedbackQuery = "INSERT INTO Feedback (neederName, missionID, description, volunteerName, neederFeedback) VALUES (?, ?, ?, ?, ?)";
                                    try (PreparedStatement feedbackStatement = connection.prepareStatement(feedbackQuery)) {
                                        feedbackStatement.setString(1, neederName);
                                        feedbackStatement.setInt(2, missionId);
                                        feedbackStatement.setString(3, description);
                                        feedbackStatement.setString(4, volunteer);
                                        feedbackStatement.setString(5, feedback);
                                        feedbackStatement.executeUpdate();
                                    	}
                                	}
                            	}
                        	}
                        // Set mission status to ended in table Missions
                        String updateMissionEnd = "UPDATE Missions SET status = 'ended' WHERE id = ?";
                        try (PreparedStatement updateMissionToEndStatement = connection.prepareStatement(updateMissionEnd)) {
                            updateMissionToEndStatement.setInt(1, missionId);
                            int rowsAffected = updateMissionToEndStatement.executeUpdate();
                        }
                    } else {
                        System.out.println("Mission doesn't exist");
                    	}
                	}
            	}
            // Close the resources
            connection.close();
            //Display message on web page
            String message = "Your feedback have been taken into account!";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (ClassNotFoundException | SQLException | IOException e) {
            e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            }
        }
    }
    
    
    //Call example : http://localhost:8095/feedback/volunteerFeedback?missionId=4&feedback=pasmal
    @GetMapping("volunteerFeedback")
    public void volunteerFeedback(@RequestParam("missionId") int missionId, @RequestParam("feedback") String feedback, HttpServletResponse response) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connect to the database
            String dbURL = "jdbc:mysql://srv-bdens.insa-toulouse.fr:3306/projet_gei_046";
            String username = "projet_gei_046";
            String password = "wahn8Xei";
            Connection connection = DriverManager.getConnection(dbURL, username, password);
            // Retrieve values related to the mission to put it in the feedback table
            String valuesQuery = "SELECT neederName, description, volunteer FROM Missions WHERE id = ?";
            try (PreparedStatement valuesStatement = connection.prepareStatement(valuesQuery)) {
                valuesStatement.setInt(1, missionId);
                try (ResultSet valuesResult = valuesStatement.executeQuery()) {
                    if (valuesResult.next()) {
                        String neederName = valuesResult.getString("neederName");
                        String description = valuesResult.getString("description");
                        String volunteer = valuesResult.getString("volunteer");    
                        // Check if the mission already exists in the Feedback table
                        String checkMissionQuery = "SELECT * FROM Feedback WHERE neederName = ? AND description = ?";
                        try (PreparedStatement checkMissionStatement = connection.prepareStatement(checkMissionQuery)) {
                            checkMissionStatement.setString(1, neederName);
                            checkMissionStatement.setString(2, description);
                            try (ResultSet checkMissionResult = checkMissionStatement.executeQuery()) {
                                if (checkMissionResult.next()) {
                                    // Mission already exists, update the feedback
                                    String updateFeedbackQuery = "UPDATE Feedback SET volunteerFeedback = ? WHERE neederName = ? AND description = ?";
                                    try (PreparedStatement updateFeedbackStatement = connection.prepareStatement(updateFeedbackQuery)) {
                                        updateFeedbackStatement.setString(1, feedback);
                                        updateFeedbackStatement.setString(2, neederName);
                                        updateFeedbackStatement.setString(3, description);
                                        updateFeedbackStatement.executeUpdate();
                                    }
                                } else {
                                    // Mission doesn't exist, insert a new feedback record
                                    String feedbackQuery = "INSERT INTO Feedback (neederName, missionID, description, volunteerName, volunteerFeedback) VALUES (?, ?, ?, ?, ?)";
                                    try (PreparedStatement feedbackStatement = connection.prepareStatement(feedbackQuery)) {
                                        feedbackStatement.setString(1, neederName);
                                        feedbackStatement.setInt(2, missionId);
                                        feedbackStatement.setString(3, description);
                                        feedbackStatement.setString(4, volunteer);
                                        feedbackStatement.setString(5, feedback);
                                        feedbackStatement.executeUpdate();
                                    	}
                                	}
                            	}
                            }
                        // Set mission status to ended in table Missions
                        String updateMissionEnd = "UPDATE Missions SET status = 'ended' WHERE id = ?";
                        try (PreparedStatement updateMissionToEndStatement = connection.prepareStatement(updateMissionEnd)) {
                            updateMissionToEndStatement.setInt(1, missionId);
                            int rowsAffected = updateMissionToEndStatement.executeUpdate();
                        }
                    } else {
                        System.out.println("Mission doesn't exist");
                        }
                    }
                }
            // Close the resources
            connection.close();
          //Display message on web page
            String message = "Your feedback have been taken into account!";
            response.getWriter().write(message);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (ClassNotFoundException | SQLException | IOException e) {
            e.printStackTrace();
            String errorMessage = "An error occured";
            try {
            	response.getWriter().write(errorMessage);
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            } catch (IOException ioException) {
            	ioException.printStackTrace();
            	}
            }
        }
    
	 }