package insa.soa.Feedback.model;

public class feedback {

	//feedback info
	public String neederName;
	public String volunteerName;
	public String missionDescription;
	public int missionID;
	public String feedback;
	
	//feedback constructor
	public feedback() {
	}
	public feedback(String neederName, String volunteerName, String missionDescription, int missionID, String feedback) {
		this.neederName = neederName;
		this.volunteerName = volunteerName;
		this.missionDescription = missionDescription;
		this.missionID = missionID;
		this.feedback = feedback;
	}
	
	//Getters
	public String getNeederName() {
		return neederName;
	}
	public String getVolunteerName() {
		return volunteerName;
	}
	public String getMissionDescription( ) {
		return missionDescription;
	}
	public String getFeedback() {
		return feedback;
	}
	public int getMissionID() {
		return missionID;
	}
	
	//Setters
	public void setNeederName(String neederName) {
		this.neederName = neederName;
	}
	public void setVolunterName(String volunteerName) {
		this.volunteerName = volunteerName;
	}
	public void setMissionDescription(String missionDescription) {
		this.missionDescription = missionDescription;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public void setMissionID(int missionID) {
		this.missionID = missionID;
	}
}
